﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WHILE
{
    class Ejemplo
    {
        static void Main(string[] args)
        {
            int edad = -1;
            while (edad < 0)
            {
                Console.WriteLine("Ingrese su edad: ");
                edad = int.Parse(Console.ReadLine());

            }
            Console.WriteLine("Su edad es: " + edad);
        }
    }
}
