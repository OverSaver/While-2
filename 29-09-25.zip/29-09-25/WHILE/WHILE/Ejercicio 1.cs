﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WHILE
{
    class Class1
    {
        static void Main(string[] args)
        {
            //Ingresar los números hasta que se introduzca un 0, para cada
            //uno de los números indicar si es par o impar.
            int num;
            Console.WriteLine("Ingrese un numero: ");
            num = int.Parse(Console.ReadLine());
            while (num > 0) {

                //par
                if (num % 2 == 0)
                {
                    Console.WriteLine("El numero es par");
                }
                else
                {
                    Console.WriteLine("El numero es impar");
                }
                Console.WriteLine("Ingrese un numero: ");
                num = int.Parse(Console.ReadLine());
            }
            Console.WriteLine("Programa finalizado");
            Console.ReadKey();
        }
    }
}
