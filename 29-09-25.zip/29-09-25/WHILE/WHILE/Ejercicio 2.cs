﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WHILE
{
    class Class2
    {
        static void Main(string[] args)
        {
            //Realizar un programa que imprima en pantalla la siguiente serie
            //numérica: 1,3,5,7,8
            int num=1;
            while (num <= 8) //1
            {
                Console.WriteLine(num + " ");//1 - 3 - 5 - 7 
                num += 2;// num = num + 2 -> 3 = 1 + 2
            }
            Console.WriteLine("8");
            Console.ReadKey();
        }
    }
}
