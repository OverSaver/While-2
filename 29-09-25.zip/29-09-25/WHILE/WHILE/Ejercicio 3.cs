﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WHILE
{
    class Class3
    {
        static void Main(string[] args)
        {
            //Se realiza un muestreo con N personas, de las cuales se
            //registran sus edades y sus pesos. Se
            //pide elaborar un programa que calcule el promedio de
            //pesos de las personas menores de 18
            //años y el promedio de pesos de los que tienen 18 años a
            //más

            int cantPer, edad, cantMen = 0, cantMay = 0, cont = 1;
            double promPeMe = 0, promPeMay = 0, peso, sumaMayPe = 0, sumaMePe = 0;
            Console.WriteLine("Ingrese la cantidad de personas: ");
            cantPer = int.Parse(Console.ReadLine());
            while (cont<=cantPer) 
            { 
                Console.WriteLine("Ingrese la edad: ");
                edad = int.Parse(Console.ReadLine());
                if (edad < 0 || edad > 100)
                {
                    Console.WriteLine("Edad incorrecta, ingrese una edad entre 0 y 100");
                    continue;
                }
                Console.WriteLine("Ingrese el peso: ");
                peso = double.Parse(Console.ReadLine());
        

                //Proceso
                if (edad >= 18 && edad <= 100) 
                {
                    sumaMayPe = sumaMayPe + peso;//suma de peso
                    cantMay++;//cantidad de personas mayores
                    promPeMay = sumaMayPe / cantMay;//promedio de peso
                }
                else 
                {
                    sumaMePe = sumaMePe + peso;//suma de peso
                    cantMen++;//cantidad de personas menores
                    promPeMe = sumaMePe / cantMen;//promedio de peso
                }
                cont++;
            }
            Console.WriteLine("El promedio de peso de las personas mayores a 18 años es: " + promPeMay);
            Console.WriteLine("El promedio de peso de las personas menores a 18 años es: " + promPeMe);
            Console.ReadKey();

        }
    }
}
